#!/bin/bash

# Keep all config values in single quotes unless specified otherwise

#Feed the new domain name of your website
NEW_DOMAIN='testd.vikilabs.org'
NEW_DB_NAME='u218639858_testa_db'
NEW_DB_USERNAME='u218639858_testa_admin'
NEW_DB_PASSWORD='Test$DB123'
NEW_DB_HOST='localhost'
NEW_DB_PORT='3306'

#OPTIONAL CONFIG [ SPECIAL PREVILAGES ]
NEW_MYSQL_ADMIN_USERNAME=''
NEW_MYSQL_ADMIN_PASSWORD=''

#Do not keep the path inside quotes 
NEW_WEBSITE_ROOT_DIR=~/public_html

  [ DOMAIN       : testa.vikilabs.org ]
    [ DB_NAME      : u218639858_testa_db ]
    [ DB_USERNAME  : u218639858_testa_admin]
    [ DB_PASSWORD  : Test$DB123 ]
    [ DB_HOST      : localhost ]
    [ DB_PORT      : 3306 ]



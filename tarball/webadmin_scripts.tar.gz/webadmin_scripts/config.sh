#enter the website address
DOMAIN="example.com"

DB_NAME="test_db"
DB_USERNAME="test_user"
DB_PASSWORD="122333"
DB_HOST="localhost"
DB_PORT=3306

#website root directory ( don't keep / at the end)
WEBSITE_ROOT_DIR="/var/www/example.com"

#website backup directory ( don't keep / at the end).
BACKUP_DIR="/var/www/backup"

LOG_FILE="${BACKUP_DIR}/${DOMAIN}_backup.log"

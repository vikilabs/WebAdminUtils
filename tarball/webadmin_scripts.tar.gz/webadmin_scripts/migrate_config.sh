#!/bin/bash

#Feed the new domain name of your website
NEW_DOMAIN="localhost"

NEW_DB_NAME="test_db"
NEW_DB_USERNAME="test_user"
#Keep the password inside single quotes ( Do not use double quotes )
NEW_DB_PASSWORD='test_password'
NEW_DB_HOST="localhost"
NEW_DB_PORT="3306"

#Do not use single or double quotes
NEW_WEBSITE_ROOT_DIR=/var/www/localhost

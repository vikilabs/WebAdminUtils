function test()
{
    source ./t.sh
    echo $T
}
test

echo $T

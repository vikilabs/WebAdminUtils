#Feed the existing domain name of your website
OLD_DOMAIN="example.com"

#Feed the new domain name of your website
NEW_DOMAIN="localhost"

#Feed the new domain name of your website
NEW_DOMAIN="localhost"

NEW_DB_NAME="test_db"
NEW_DB_USERNAME="test_user"
NEW_DB_PASSWORD="test_password"
NEW_DB_HOST="localhost"
NEW_DB_PORT="3306"

NEW_WEBSITE_ROOT_DIR="/var/www/localhost"
